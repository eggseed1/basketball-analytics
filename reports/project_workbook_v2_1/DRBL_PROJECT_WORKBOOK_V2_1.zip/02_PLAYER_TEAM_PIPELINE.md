# Player team pipeline
NBA Stats �� normalizeNbaPlayerSeasonTeam �� PlayerSeason.teamId (canonical) �� Explore/Player UI
